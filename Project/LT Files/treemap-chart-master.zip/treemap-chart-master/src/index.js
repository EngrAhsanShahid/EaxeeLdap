import './treemap.css';

export { default } from './treemap';
